create function pgaadauth_update_principal_with_oid(rolename text, objectid text, objecttype text, isadmin boolean, ismfa boolean) returns text
    language plpgsql
as
$$
    DECLARE securityLabel text := 'aadauth';
    DECLARE securityLabelQuery text;
    DECLARE query text;
    BEGIN
        IF objectId IS NOT NULL AND objectId != '' THEN
            securityLabel := CONCAT(securityLabel, CONCAT(',oid=', objectId));
            IF objectType IS NOT NULL AND objectType != '' THEN
                securityLabel := CONCAT(securityLabel, CONCAT(',type=', objectType));
            END IF;

            IF isAdmin IS TRUE THEN
                securityLabel := CONCAT(securityLabel, ',admin');
            END IF;

            IF isMfa IS TRUE THEN
                securityLabel := CONCAT(securityLabel, ',mfa');
            END IF;

            securityLabelQuery := FORMAT('SECURITY LABEL for "pgaadauth" on role %1$s is %2$s', quote_ident(roleName) , quote_literal(securityLabel));

            EXECUTE securityLabelQuery;

            RETURN FORMAT('Updated role for %1$s', quote_ident(roleName));
        END IF;
    END;
$$;

alter function pgaadauth_update_principal_with_oid(text, text, text, boolean, boolean) owner to azuresu;

