create function pgaadauth_pgbouncer_auth_query(rolename text, credentials text)
    returns TABLE(username text, objectid text, errormessage text)
    language plpgsql
as
$$
    DECLARE _has_sec_label text;
    DECLARE _error_message text;
    BEGIN
        SELECT has_sec_label, error_message
            INTO _has_sec_label, _error_message
            FROM pgaadauth_pgbouncer_auth_type_query(roleName);

        -- Perform the query logic
		IF (_error_message = '') IS FALSE THEN
			RETURN QUERY
                SELECT '', '', _error_message;
        ELSIF _has_sec_label = '0' THEN
			RETURN QUERY
                SELECT '', '', 'Internal Server Error: Label could not be found. pgaadauth_pgbouncer_auth_query should be used only for principals';
        ELSE
			RETURN QUERY
                SELECT user_name, object_id, error_message
                FROM pgaadauth_validate_token(credentials, roleName)
                WHERE user_name != '' or error_message != '';
        END IF;
    END
$$;

alter function pgaadauth_pgbouncer_auth_query(text, text) owner to azuresu;

